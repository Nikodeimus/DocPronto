@echo off
setlocal
chcp 65001 >nul
set "TARGET=%USERPROFILE%\Documents\DOCPronto"
set "SOURCE=%~dp0server.mjs"

if not exist "%SOURCE%" (
  echo ERRO: o arquivo server.mjs nao foi encontrado junto deste atualizador.
  pause
  exit /b 1
)

if not exist "%TARGET%" (
  echo ERRO: a pasta "%TARGET%" nao foi encontrada.
  echo Extraia este ZIP e execute o atualizador neste computador.
  pause
  exit /b 1
)

taskkill /F /IM node.exe >nul 2>&1
if exist "%TARGET%\server.mjs" copy /Y "%TARGET%\server.mjs" "%TARGET%\server.mjs.backup" >nul
copy /Y "%SOURCE%" "%TARGET%\server.mjs" >nul

echo Conector do DOCPronto atualizado com sucesso.
if exist "%TARGET%\ABRIR DOCPRONTO.cmd" start "" "%TARGET%\ABRIR DOCPRONTO.cmd"
if not exist "%TARGET%\ABRIR DOCPRONTO.cmd" if exist "%TARGET%\abrir-docpronto.cmd" start "" "%TARGET%\abrir-docpronto.cmd"
pause
